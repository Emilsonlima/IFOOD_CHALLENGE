package br.com.ifood.dao.impl;

import java.util.List;

import br.com.ifood.bean.Endereco;
import br.com.ifood.bean.PrecoMedio;
import br.com.ifood.dao.PrecoMedioDAO;
import br.com.ifood.exception.DBException;

public class OraclePrecoMedioDao implements PrecoMedioDAO {

	@Override
	public void cadastrar(PrecoMedio precomedio) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(PrecoMedio precomedio) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remover(PrecoMedio precomedio) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Endereco buscar(int id_precomedio) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PrecoMedio> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remover(int id_precomedio) throws DBException {
		// TODO Auto-generated method stub
		
	}

	
}
