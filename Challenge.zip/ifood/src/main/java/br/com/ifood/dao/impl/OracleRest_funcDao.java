package br.com.ifood.dao.impl;

import java.util.List;

import br.com.ifood.bean.Rest_func;
import br.com.ifood.dao.Rest_FuncDAO;
import br.com.ifood.exception.DBException;

public class OracleRest_funcDao implements Rest_FuncDAO{

	@Override
	public void cadastrar(Rest_func rest_func) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(Rest_func rest_func) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remover(Rest_func rest_func) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Rest_func buscar(int id_restaurante) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Rest_func> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remover(int id_restaurante) throws DBException {
		// TODO Auto-generated method stub
		
	}

}
