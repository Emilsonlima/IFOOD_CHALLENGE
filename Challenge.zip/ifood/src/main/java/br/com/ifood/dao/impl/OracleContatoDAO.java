package br.com.ifood.dao.impl;

import java.util.List;

import br.com.ifood.bean.Contato;
import br.com.ifood.dao.contatoDAO;
import br.com.ifood.exception.DBException;


public class OracleContatoDAO implements contatoDAO {

	@Override
	public void cadastrar(Contato contato) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(Contato contato) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remover(Contato contato) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Contato buscar(int id_contato) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Contato> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remover(int id_contato) throws DBException {
		// TODO Auto-generated method stub
		
	}

}
	
	