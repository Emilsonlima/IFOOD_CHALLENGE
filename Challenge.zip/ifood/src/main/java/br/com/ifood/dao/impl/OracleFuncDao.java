package br.com.ifood.dao.impl;

import java.util.List;

import br.com.ifood.bean.Contato;
import br.com.ifood.bean.FUNC;
import br.com.ifood.dao.FUNCDAO;
import br.com.ifood.exception.DBException;

public class OracleFuncDao implements FUNCDAO{

	@Override
	public void cadastrar(FUNC func) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(FUNC func) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remover(FUNC func) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Contato buscar(int cd_dia_func) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<FUNC> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remover(int cd_dia_func) throws DBException {
		// TODO Auto-generated method stub
		
	}

	
}
