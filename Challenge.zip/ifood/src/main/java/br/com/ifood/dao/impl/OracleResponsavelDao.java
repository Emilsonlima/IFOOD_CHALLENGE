package br.com.ifood.dao.impl;

import java.util.List;

import br.com.ifood.bean.Endereco;
import br.com.ifood.bean.Responsavel;
import br.com.ifood.dao.ResponsavelDAO;
import br.com.ifood.exception.DBException;

public class OracleResponsavelDao implements ResponsavelDAO{

	@Override
	public void cadastrar(Responsavel responsavel) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(Responsavel responsavel) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void remover(Responsavel responsavel) throws DBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Endereco buscar(int id_responsavel) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Endereco> listar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remover(int responsavel) throws DBException {
		// TODO Auto-generated method stub
		
	}

}
